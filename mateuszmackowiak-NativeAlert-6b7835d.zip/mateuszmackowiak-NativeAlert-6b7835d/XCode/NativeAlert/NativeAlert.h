//
//  NativeAlert.h
//  NativeAlert
//
//  Created by Anthony McCormick on 23/10/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MobileAlert.h"

@interface NativeAlert : NSObject <UIAlertViewDelegate>


@end