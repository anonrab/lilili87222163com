-------------------------------------------------------------------------------
Native Alert for iOS
-------------------------------------------------------------------------------
Wolfgang Klopf
www.wolfknock.com
-------------------------------------------------------------------------------
Extension ID: com.wolfknock.idialog
-------------------------------------------------------------------------------

----------
*OVERVIEW*
----------

This library allows to open a native alert on iOS

For this to work, you'll need:

1. Add the iNativeDialog.swc to Library - External library (not included)
2. Add node to your application.xml -> <extensions><extensionID>com.wolfknock.idialog</extensionID></extensions>
3. Targeting AIR v 3.0 or higher
4. Include the extension idialogextension.ane in your build
			

----------
*SAMPLE USAGE*
----------

Your class:
import com.wolfknock.air.extensions.ios.NativeDialog;
.....
private var dialog:NativeDialog;
....
dialog = new NativeDialog();
dialog.addEventListener(NativeDialog.NATIVE_DIALOG_CLICKED, nativeDialogClickedHandler); // Optional. NE dipatches event after the Alert button has been clicked.
dialog.showNativeDialog("Native Alert Title", "Adobe Air Native Extensions", "YES"); // Titel, Message, Button text (optional)
....
dialog.dispose(); // best after receiving NativeDialog.NATIVE_DIALOG_CLICKED event

-------------------------------------------------------------------------------
*ANY QUESTIONS*
-------------------------------------------------------------------------------
me@wolfknock.com


Copyright (c) 2011 Wolfgang Klopf

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.