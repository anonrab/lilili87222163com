You need to add your FlurryAnalytics library folder (containing FlurryAnalytics.h & libFlurryAnalytics.a )
and the FlashRuntimeExtensions.h header file (from the Adobe Air SDK) to this directory before building
the project.