cp /Users/jli/Library/Developer/Xcode/DerivedData/ANEGameKit-essvjfsbtupscxbjcjwxjsluqbwq/Build/Products/Debug-iphoneos/libANEGameKit.a /Users/jli/Documents/James\ Li/Projects/GameCenter_Example/_bin/
unzip -o GameKit.swc
bin/adt -package -storetype pkcs12 -keystore selfsigned.p12 -storepass 1234 -target ane ext/GK.ane extension.xml -swc GameKit.swc -platform iPhone-ARM  library.swf libANEGameKit.a 
bin/adt -package -target ipa-test-interpreter -provisioning-profile gamecenterexample_dev.mobileprovision -storetype pkcs12 -keystore jameslidevelopment.p12 -storepass 1234 Main.ipa info-app.xml GameCenterExample.swf -extdir ext assets
