//
//  ANEGameKit.m
//  ANEGameKit
//
//  Created by James Li on 11/3/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ANEGameKit.h"

@implementation ANEGameKit

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
