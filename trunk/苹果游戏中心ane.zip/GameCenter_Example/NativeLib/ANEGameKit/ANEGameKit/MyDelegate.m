//
//  MyDelegate.m
//  GameCenterLib
//
//  Created by James Li on 10/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyDelegate.h"

BOOL matchStarted = NO;

NSArray *players;


@implementation MyDelegate

@synthesize isHost;
@synthesize myMatch;
@synthesize gameSession;
@synthesize displayName;
@synthesize expectedPlayerCount;
//@synthesize g_ctx;


- (void) authenticationChanged{
   /* GKLocalPlayer *localPlayer = [GKLocalPlayer localPlayer];
    if(localPlayer.isAuthenticated){
        NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
        [retXML appendFormat:@"<i>%@</i>",localPlayer.playerID];
        [retXML appendFormat:@"<a>%@</a>",localPlayer.alias];
        [retXML appendFormat:@"</p>"];
        FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"authenticate_status_changed",(const uint8_t*)[retXML UTF8String]);
        //[retXML release];
        handleInvitation();
    }else{
        FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"authenticate_status_changed",(const uint8_t*)"");
    }*/
}

- (void)leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController{
    
}


- (void)matchmakerViewControllerWasCancelled:(GKMatchmakerViewController *)viewController{
    dismissModalViewController(viewController);
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"request_match_cancelled", (const uint8_t*)"");
}

- (void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFailWithError:(NSError *)error{
    dismissModalViewController(viewController);
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"request_match_failed", (const uint8_t*)"");
}

- (void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFindMatch:(GKMatch *)match
{
    dismissModalViewController(viewController);
    self.myMatch = match; // Use a retaining property to retain the match.
    self.myMatch.delegate = self;
    
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"request_match_complete", (const uint8_t*)"");

    if (!matchStarted && match.expectedPlayerCount == 0)
    {
        matchStarted = YES;
        initializeMatchPlayers();
    }
}

- (void)match:(GKMatch *)match player:(NSString *)playerID didChangeState:(GKPlayerConnectionState)state
{
    NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
    [retXML appendFormat:@"<i>%@</i>",playerID];
    
    switch (state)
    {
        case GKPlayerStateConnected:
            // handle a new player connection.
            [retXML appendFormat:@"<s>1</s></p>"];
            break;
        case GKPlayerStateDisconnected:
            [retXML appendFormat:@"<s>0</s></p>"];
            // a player just disconnected.
            break;
    }
    
    
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"player_status_changed",(const uint8_t*)[retXML UTF8String]);
    //[retXML release];
    
    if (!matchStarted && match.expectedPlayerCount == 0)
    {
        matchStarted = YES;
        initializeMatchPlayers();        
    }
    
    
}



- (void)match:(GKMatch *)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID{
    handleReceivedData(data);
}






/**
 If a server received a client request;
 */
- (void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *)peerID{
    NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
    [retXML appendFormat:@"<i>%@</i>", peerID];
    [retXML appendFormat:@"<a>%@</a>", [session displayNameForPeer:peerID]];
    [retXML appendFormat:@"</p>"];
    
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"received_client_request",(const uint8_t*)[retXML UTF8String]);
    //[retXML release];
}

/* Indicates a connection error occurred with a peer, which includes connection request failures, or disconnects due to timeouts.
 */
- (void)session:(GKSession *)session connectionWithPeerFailed:(NSString *)peerID withError:(NSError *)error{
    NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
    [retXML appendFormat:@"<i>%@</i>", peerID];
    [retXML appendFormat:@"<a>%@</a>", [session displayNameForPeer:peerID]];
    [retXML appendFormat:@"</p>"];

    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"connection_failed",(const uint8_t*)[retXML UTF8String]);
   // [retXML release];

}

/* Indicates an error occurred with the session such as failing to make available.
 */
- (void)session:(GKSession *)session didFailWithError:(NSError *)error{
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"connection_error",(const uint8_t*)"");
}

- (void)session:(GKSession *)session peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state
{
    
    NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
    [retXML appendFormat:@"<i>%@</i>", peerID];
    [retXML appendFormat:@"<a>%@</a>", [session displayNameForPeer:peerID]];
    
   // NSArray *connectedPeers1 = [session peersWithConnectionState:GKPeerStateConnected];
   /* UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Leaderboard?" 
                                                    message:(expectedPlayerCount==1)?@"1":(expectedPlayerCount==2 ? @"2": @"no") delegate:nil 
                                          cancelButtonTitle:@"Cancel" 
                                          otherButtonTitles:@"Say Hello",nil];
    [alert show];*/
    
    
    switch (state)
    {
            
        case GKPeerStateAvailable:
            /**
             First time discover a server;
             */
            [retXML appendFormat:@"<s>available</s>"];
            break;
        case GKPeerStateUnavailable:
            /**
             First time lose a server;
             */
            [retXML appendFormat:@"<s>unavailable</s>"];
            break;
        case GKPeerStateConnected:
            // Record the peerID of the other peer.
            // Inform your game that a peer has connected.
             [retXML appendFormat:@"<s>connected</s>"];
            
            /**
             For Peer - Peer mode, you need HERE to check whether the connected peers count reaches expected player count,
             then to initialize the game.
             */
           
           // NSLog(@"1");            
            if([session sessionMode] == GKSessionModePeer){
                // NSLog(@"2"); 
                NSArray *connectedPeers = [session peersWithConnectionState:GKPeerStateConnected];                
                if([connectedPeers count] == expectedPlayerCount-1){
                    // NSLog(@"3"); 
                    initializeSessionPlayers(session, connectedPeers);
                }
            }
            
            break;
        case GKPeerStateDisconnected:
            // Inform your game that a peer has left.
             [retXML appendFormat:@"<s>disconnected</s>"];
            break;
        default:
            break;
    }
    [retXML appendFormat:@"</p>"];
    
    
    
    
    
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"player_status_changed",(const uint8_t*)[retXML UTF8String]);

}


- (void) receiveData:(NSData *)data fromPeer:(NSString *)peer inSession: (GKSession *)session context:(void *)context
{
    NSLog([NSString stringWithUTF8String:(const char*)[data bytes]]);
    handleReceivedData(data);
}



@end


