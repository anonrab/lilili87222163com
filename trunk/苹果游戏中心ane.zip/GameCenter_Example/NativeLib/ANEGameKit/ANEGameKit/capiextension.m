//
//  capiextension.m
//  GameCenterLib
//
//  Created by James Li on 10/9/11.
//  Copyright 2011 Adobe Systems. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import "UIKit/UIKit.h"
#import "MyDelegate.h"
#import <Foundation/Foundation.h>
#import <GameKit/GameKit.h>

FREContext g_ctx=nil;
MyDelegate *observer =nil;

UIViewController *currentModalViewController = nil;


/**
 Debug method, 
 Call from ActionScript to create a native alert window.
 */
FREObject alert(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* title = nil;
    const uint8_t* msg = nil;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[0], &len, &title);
    FREGetObjectAsUTF8(argv[1], &len, &msg);
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithUTF8String:(const char *)title]
                                                    message:[NSString stringWithUTF8String:(const char *)msg] delegate:nil 
                                          cancelButtonTitle:@"Cancel" 
                                          otherButtonTitles:nil,nil];
    [alert show];
    //[alert release];
    
    
    return nil;
}

/**
 Game Center mode only, trying to log into game center.
 */
FREObject authenticate(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {

    GKLocalPlayer *localPlayer = [GKLocalPlayer localPlayer];
   [localPlayer authenticateWithCompletionHandler:^(NSError *error) {
        GKLocalPlayer *lp = [GKLocalPlayer localPlayer];
        if(lp.isAuthenticated){
            NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<p>"];
            [retXML appendFormat:@"<i>%@</i>",lp.playerID];
            [retXML appendFormat:@"<a>%@</a>",lp.alias];
            [retXML appendFormat:@"</p>"];
            FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"authenticate_status_changed",(const uint8_t*)[retXML UTF8String]);
            handleInvitation();
        }else{
            FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"authenticate_status_changed",(const uint8_t*)"");
        }
    }];
   // [localPlayer authenticateWithCompletionHandler:nil];
   // NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
   // [nc addObserver:observer selector:@selector(authenticationChanged:) name:GKPlayerAuthenticationDidChangeNotificationName object:nil]; 
    return nil;
}

/**
 Returns a system language identifier,
 */
FREObject getSystemLocale(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    NSString *lan = [[NSLocale preferredLanguages] objectAtIndex:0]; 
    
    FREObject reVal;
    FRENewObjectFromUTF8((uint32_t)[lan length], (const uint8_t*)[lan UTF8String], &reVal);
   // [lan release];
    return reVal;
};

/**
 Check whether Game Center is available on your device.
 */
FREObject isGCAvailable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    BOOL localPlayerClassAvailable = (NSClassFromString(@"GKLocalPlayer")) != nil;
    
    // The device must be running iOS 4.1 or later.
    NSString *reqSysVer = @"4.1";
    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
    BOOL osVersionSupported = ([currSysVer compare:reqSysVer options:NSNumericSearch] != NSOrderedAscending);
    
    FREObject reVal;
    FRENewObjectFromBool((localPlayerClassAvailable && osVersionSupported),&reVal);
    //[reqSysVer release];
    //[currSysVer release];
    return reVal;
};

/**
 Check whether Bluetooth is available on your device.
 */
FREObject isBluetoothAvailable(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    FREObject reVal;
    FRENewObjectFromBool(YES,&reVal);
    return reVal;
}

/**
 Request and display a standard user interface of Game Center match maker.
 */
FREObject requestMatchMaker(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]) {
    uint32_t min = 2;
    uint32_t max = 2;
    FREGetObjectAsUint32(argv[0], &min);
    FREGetObjectAsUint32(argv[1], &max);
    showMatchMaker(min,max);
    return nil;
}

/**
 Request a peer session, difference from server mode and client mode.
 */
FREObject requestPeerMatch(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){

    const uint8_t* myName = nil;
    uint32_t sessionMode = 1;
    uint32_t expectedPlayerCount = 2;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[0], &len, &myName);
    FREGetObjectAsUint32(argv[1], &sessionMode);
    FREGetObjectAsUint32(argv[2], &expectedPlayerCount);
    
    observer.displayName = [NSString stringWithUTF8String:(const char *)myName];
    observer.expectedPlayerCount = expectedPlayerCount;
    
    //[alert release];
    
    
    
    
    GKSession* session = [[GKSession alloc] initWithSessionID:[NSString stringWithFormat:@"com.jamesli.treasurehunters_%d@",expectedPlayerCount]
                displayName:observer.displayName 
                sessionMode: (sessionMode == 2) ? GKSessionModeServer : (sessionMode == 1)? GKSessionModePeer : GKSessionModeClient];
    observer.gameSession = session;
    
    //[mode release];
    
    [session setDataReceiveHandler:observer withContext:nil];
    session.delegate = observer;
    session.available = YES;
    
    FREObject reVal;
    FRENewObjectFromUTF8((uint32_t)[session.peerID length], (const uint8_t*)[session.peerID UTF8String], &reVal);
    return reVal;
}

/**
 Accepts a connecting client as a server.
 */
FREObject acceptPeer(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* peerID = nil;
    uint32_t len = -1;
    FREGetObjectAsUTF8(argv[0], &len, &peerID);

   // NSError *error = nil;
    [observer.gameSession acceptConnectionFromPeer:[NSString stringWithUTF8String:(const char *)peerID] error:nil];
    
    return nil;
}

/**
 Rejects a connecting client as a server.
 */
FREObject denyPeer(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* peerID = nil;
    uint32_t len = -1;
    FREGetObjectAsUTF8(argv[0], &len, &peerID);
    
    [observer.gameSession denyConnectionFromPeer:[NSString stringWithUTF8String:(const char *)peerID]];
    return nil;
}

/**
 Trying to connect a server as a client.
 */
FREObject joinServer(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* peerID = nil;
    uint32_t len = -1;
    FREGetObjectAsUTF8(argv[0], &len, &peerID);
    
    uint32_t timeInterval = 10000;
    
    [observer.gameSession connectToPeer:[NSString stringWithUTF8String:(const char *)peerID] withTimeout:timeInterval];
    return nil;
}

/**
 Broadcast a message to selected Game Center match players.
 */
FREObject sendDataToGCPlayers(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* msg = nil;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[1], &len, &msg);
    const char* datachar = (const char*) msg;
    
    
    const uint8_t* playerIDs = nil;
    uint32_t plen = -1;
    
    FREGetObjectAsUTF8(argv[0], &plen, &playerIDs);

    
    NSString *playerIDStr = [[NSString alloc] initWithString:[NSString stringWithUTF8String:(const char*)playerIDs]];
    NSArray *players = [playerIDStr componentsSeparatedByString:@","];
    //[playerIDStr release];
    
    //NSError **error=nil;
    NSData *packet = [NSData dataWithBytes:datachar length:strlen(datachar)];
    [observer.myMatch sendData:packet toPlayers:players withDataMode:GKSendDataUnreliable error:nil];   
    return nil;
    
}

/**
 Boardcast a message to all Session peers.
 */
FREObject sendDataToPeers(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* msg = nil;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[1], &len, &msg);
    const char* datachar = (const char*) msg;
    
    
    const uint8_t* playerIDs = nil;
    uint32_t plen = -1;
    
    FREGetObjectAsUTF8(argv[0], &plen, &playerIDs);

    NSString *playerIDStr = [[NSString alloc] initWithString:[NSString stringWithUTF8String:(const char*)playerIDs]];
    NSArray *players = [playerIDStr componentsSeparatedByString:@","];
    //[playerIDStr release];
    
    NSError *error;
    NSData *packet = [NSData dataWithBytes:datachar length:strlen(datachar)];
    [observer.gameSession sendData:packet toPeers:players withDataMode:GKSendDataUnreliable error:&error];
    
    
    
    NSLog([NSString stringWithUTF8String:(const char*)msg]);
    return nil;
}

/**
 Disconnect from Game Center Match;
 */
FREObject disconnectFromGCMatch(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    if(observer.myMatch!=nil){
        [observer.myMatch disconnect];
        //[observer.myMatch release];
    }
    return nil;
}
/**
 Disconnect from certain session peer;
 */
FREObject disconnectFromPeer(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* peerID = nil;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[0], &len, &peerID);
    if([observer gameSession]!=nil){
        [[observer gameSession] disconnectPeerFromAllPeers:[NSString stringWithUTF8String:(const char*)peerID]];
    }
    return nil;
}

/**
 Disconnect from all other session peers;
 */
FREObject disconnectFromAllPeers(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    if([observer gameSession]!=nil){
        [[observer gameSession] disconnectFromAllPeers];
        [observer gameSession].available = NO;
        [[observer gameSession] setDataReceiveHandler: nil withContext: nil];
        [observer gameSession].delegate = nil;
       // [[observer gameSession] release];
    }
    return nil;
}
/**
While entering match, you need to lock the session so nobody will search this session.
*/
FREObject lockSession(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    if([observer gameSession]!=nil){
        [observer gameSession].available = NO;
    }
    return nil;
} 



FREObject showLeaderBoard(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    GKLeaderboardViewController *leaderboardController = [[GKLeaderboardViewController alloc] init];
    if (leaderboardController != nil)
    {
        const uint8_t* category = nil;
        uint32_t len = -1;
        
        if(argc>0){
            if(FREGetObjectAsUTF8(argv[0], &len, &category) == FRE_OK){
                leaderboardController.category = [NSString stringWithUTF8String:(const char *) category];
            }
        }
        
        
        leaderboardController.timeScope = GKLeaderboardTimeScopeToday;
        leaderboardController.leaderboardDelegate = observer;
        // UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        showModalViewController(leaderboardController);
        
        
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Leaderboard?" 
                                                        message:@"Not Support" delegate:nil 
                                              cancelButtonTitle:@"Cancel" 
                                              otherButtonTitles:@"Say Hello",nil];
        [alert show];
       // [alert release];
        
    }
    return nil;
}

FREObject retrieveTopScores(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]) {
    GKLeaderboard *leaderboardRequest = [[GKLeaderboard alloc] init];
    
    if (leaderboardRequest != nil)
    {
        const uint8_t* category = nil;
        uint32_t len = -1;
        
        if(FREGetObjectAsUTF8(argv[0], &len, &category) == FRE_OK){
            leaderboardRequest.category = [NSString stringWithUTF8String:(const char *) category];
        }
        
        uint32_t mount = 10;
        if(FREGetObjectAsUint32(argv[1], &mount) == FRE_OK){
            leaderboardRequest.range = NSMakeRange(1,mount);
        };
        leaderboardRequest.playerScope = GKLeaderboardPlayerScopeGlobal;
        leaderboardRequest.timeScope = GKLeaderboardTimeScopeAllTime;
        [leaderboardRequest loadScoresWithCompletionHandler: ^(NSArray *scores, NSError *error) {
            if (error != nil)
            {
                
                // handle the error.
                FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"retrieve_top_scores_error",nil);
            }
            if (scores != nil)
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Leaderboard?" 
                                                                message:@"scores" delegate:nil 
                                                      cancelButtonTitle:@"Cancel" 
                                                      otherButtonTitles:@"Say Hello",nil];
                [alert show];
               // [alert release];
                
                // process the score information.
                NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<scores>"];
                for(NSString *score in scores){
                    [retXML appendFormat:@"<score>%@</score>", score];
                }
                [retXML appendFormat:@"</scores>"];
                FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"retrieve_top_scores_complete",(const uint8_t*)[retXML UTF8String]);
              //  [retXML release];
            }
        }];
    }
    return nil;
}





FREObject reportScore(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* category = nil;
    uint32_t len = -1;
    
    if(FREGetObjectAsUTF8(argv[0], &len, &category) == FRE_OK){
        GKScore *scoreReporter = [[GKScore alloc] initWithCategory:[NSString stringWithUTF8String:(const char *) category]];
        scoreReporter.value = 1010;
        [scoreReporter reportScoreWithCompletionHandler:^(NSError *error) {
            if (error != nil)
            {
                // handle the reporting error
                FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"report_score_error",nil);
            }else{
                FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"report_score_compolete",nil);
            }
        }];
    }
    return nil;
}


FREObject disconnectMatch(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    
    return nil;
}






void ContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, 
                        uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
	NSLog(@"Context Created");
	*numFunctionsToTest = 16;
	FRENamedFunction* func = (FRENamedFunction*)malloc(sizeof(FRENamedFunction)*16);
    func[0].name = (const uint8_t*)"getSystemLocale";
	func[0].functionData = NULL;
	func[0].function = &getSystemLocale; 
    
	func[1].name = (const uint8_t*)"isGCAvailable";
	func[1].functionData = NULL;
	func[1].function = &isGCAvailable; 
    
    func[2].name = (const uint8_t*)"isBluetoothAvailable";
	func[2].functionData = NULL;
	func[2].function = &isBluetoothAvailable; 
    
    func[3].name = (const uint8_t*)"requestMatchMaker";
	func[3].functionData = NULL;
	func[3].function = &requestMatchMaker;
    
    func[4].name = (const uint8_t*)"requestPeerMatch";
	func[4].functionData = NULL;
	func[4].function = &requestPeerMatch;
    
    func[5].name = (const uint8_t*)"alert";
	func[5].functionData = NULL;
	func[5].function = &alert;
    
    func[6].name = (const uint8_t*)"authenticate";
	func[6].functionData = NULL;
	func[6].function = &authenticate;
    
    func[7].name = (const uint8_t*)"acceptPeer";
	func[7].functionData = NULL;
	func[7].function = &acceptPeer;
    
    func[8].name = (const uint8_t*)"denyPeer";
	func[8].functionData = NULL;
	func[8].function = &denyPeer;
    
    func[9].name = (const uint8_t*)"joinServer";
	func[9].functionData = NULL;
	func[9].function = &joinServer;
    
    func[10].name = (const uint8_t*)"sendDataToGCPlayers";
	func[10].functionData = NULL;
	func[10].function = &sendDataToGCPlayers;
    
    func[11].name = (const uint8_t*)"sendDataToPeers";
	func[11].functionData = NULL;
	func[11].function = &sendDataToPeers;
    
    func[12].name = (const uint8_t*)"disconnectFromGCMatch";
	func[12].functionData = NULL;
	func[12].function = &disconnectFromGCMatch;
    
    func[13].name = (const uint8_t*)"disconnectFromAllPeers";
	func[13].functionData = NULL;
	func[13].function = &disconnectFromAllPeers;
    
    func[14].name = (const uint8_t*)"disconnectFromPeer";
	func[14].functionData = NULL;
	func[14].function = &disconnectFromPeer;
    
    func[15].name = (const uint8_t*)"lockSession";
	func[15].functionData = NULL;
	func[15].function = &lockSession;
    
    
    g_ctx = ctx;
    observer = [[MyDelegate alloc] init];
 
    
	*functionsToSet = func;
	//// Set the globals.
}

void ContextFinalizer(FREContext ctx) { 
	NSLog(@"Context Distroyed");
}

void ExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet) {
	NSLog(@"Extension Initialized");
	*extDataToSet = NULL;
	*ctxInitializerToSet = &ContextInitializer;
	*ctxFinalizerToSet = &ContextFinalizer;
}

void ExtFinalizer(void* extData) {
	NSLog(@"Extension Destroyed");
}


void showModalViewController(UIViewController* viewController){
    if(currentModalViewController!=nil){
        dismissModalViewController(currentModalViewController);
    }
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    UIViewController *parentViewController = [[UIViewController alloc] init];
    [window addSubview:parentViewController.view];
    [parentViewController presentModalViewController:viewController animated:YES];
    currentModalViewController = viewController;
   // [viewController release];
    
}
void dismissModalViewController(UIViewController* viewController){
    if(viewController !=nil){
        UIViewController *parentViewController = [viewController parentViewController];
        [parentViewController dismissModalViewControllerAnimated:NO];
        [parentViewController.view removeFromSuperview];
        //[parentViewController release];
        currentModalViewController = nil;
    }
}

void showMatchMaker(uint32_t min, uint32_t max){
    GKMatchRequest *request = [[GKMatchRequest alloc] init];
    request.minPlayers = min;
    request.maxPlayers = max;
    
    GKMatchmakerViewController *mmvc = [[GKMatchmakerViewController alloc] initWithMatchRequest:request];
    mmvc.matchmakerDelegate = observer;
    
    showModalViewController(mmvc);
    
    [[GKMatchmaker sharedMatchmaker] queryActivityWithCompletionHandler:^(NSInteger activity, NSError *error) {
        if (error)
        {
            // Process the error.
        }
        else
        {
            // Use the activity value to display activity to the player.
        }
    }];
}
void handleInvitation(){
    [GKMatchmaker sharedMatchmaker].inviteHandler = ^(GKInvite *acceptedInvite, NSArray *playersToInvite) {
        // Insert application-specific code here to clean up any games in progress.
        if (acceptedInvite)
        {
            GKMatchmakerViewController *mmvc = [[GKMatchmakerViewController alloc] initWithInvite:acceptedInvite];
            mmvc.matchmakerDelegate = observer;
            showModalViewController(mmvc);
            
            //  observer.isHost = NO;
        }
        else if (playersToInvite)
        {
            GKMatchRequest *request = [[GKMatchRequest alloc] init];
            request.minPlayers = 2;
            request.maxPlayers = 4;
            request.playersToInvite = playersToInvite;
            
            GKMatchmakerViewController *mmvc = [[GKMatchmakerViewController alloc] initWithMatchRequest:request];
            mmvc.matchmakerDelegate = observer;
            showModalViewController(mmvc);
            
            // observer.isHost = YES;
        }
    };
}

void initializeMatchPlayers(){
    [GKPlayer loadPlayersForIdentifiers:[observer.myMatch playerIDs] withCompletionHandler:^(NSArray *players, NSError *error) {
        
        if(error){
            //Handler load player info error;
        }else{
            NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<m>"];
            //[retXML appendFormat:@"<p>"];
            for(GKPlayer *player in players){
                [retXML appendFormat:@"<p>"];
                [retXML appendFormat:@"<i>%@</i>",player.playerID];
                [retXML appendFormat:@"<a>%@</a>",player.alias];
                [retXML appendFormat:@"</p>"];
            };
            //[retXML appendFormat:@"</p>"];
            [retXML appendFormat:@"</m>"];
            
            FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"match_players_initialized", (const uint8_t*)[retXML UTF8String]);
            //[retXML release];
        };
        
    }];

}

void initializeSessionPlayers(GKSession *session, NSArray *peers){
    NSMutableString* retXML = [[NSMutableString alloc] initWithString:@"<m>"];
    //[retXML appendFormat:@"<p>"];
    for( NSString *peerID in peers){
        [retXML appendFormat:@"<p>"];
        [retXML appendFormat:@"<i>%@</i>",peerID];
        [retXML appendFormat:@"<a>%@</a>",[session displayNameForPeer:peerID]];
        [retXML appendFormat:@"</p>"];
    };
   // [retXML appendFormat:@"</p>"];
    [retXML appendFormat:@"</m>"];
    // NSLog(retXML); 
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"match_players_initialized", (const uint8_t*)[retXML UTF8String]);
   // [retXML release];

}



void receiveFromPeer(NSData *data, NSString *peer, GKSession *session, void *context)
{
    handleReceivedData(data);
}


void handleReceivedData(NSData *data){
    
    
    
    // Read the bytes in data and perform an application-specific action.
    NSString *datastr = [NSString stringWithUTF8String:[data bytes]];
    FREDispatchStatusEventAsync(g_ctx, (const uint8_t*)"received_data_from",(const uint8_t*)[datastr UTF8String]);
    //[datastr release];
}






