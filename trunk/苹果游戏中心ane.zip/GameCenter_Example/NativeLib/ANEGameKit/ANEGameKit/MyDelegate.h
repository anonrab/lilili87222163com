//
//  MyDelegate.h
//  GameCenterLib
//
//  Created by James Li on 10/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlashRuntimeExtensions.h"

#import <GameKit/GameKit.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern FREContext g_ctx;


void showModalViewController(UIViewController*);
void dismissModalViewController(UIViewController*);
void handleInvitation();
void showMatchMaker(uint32_t min, uint32_t max);
void initializeMatchPlayers();
void initializeSessionPlayers(GKSession *session, NSArray *peers);
void handleReceivedData(NSData *data);

@interface MyDelegate : NSObject <GKLeaderboardViewControllerDelegate,
GKMatchmakerViewControllerDelegate,
GKMatchDelegate,GKSessionDelegate>{
}

@property BOOL isHost;
@property uint32_t expectedPlayerCount;
@property(retain) __attribute__((NSObject)) NSString *displayName;
@property(retain) __attribute__((NSObject)) GKMatch *myMatch;
@property(retain) __attribute__((NSObject)) GKSession *gameSession;
//@property FREContext g_ctx;

- (void) authenticationChanged;

/**
 *GKLeaderboardViewControllerDelegate:
 */

// The leaderboard view has finished
- (void)leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController;


/**
 * GKMatchmakerViewControllerDelegate
 */

// The user has cancelled matchmaking
- (void)matchmakerViewControllerWasCancelled:(GKMatchmakerViewController *)viewController;

// Matchmaking has failed with an error
- (void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFailWithError:(NSError *)error;

// A peer-to-peer match has been found, the game should start
- (void)matchmakerViewController:(GKMatchmakerViewController *)viewController didFindMatch:(GKMatch *)match;


/**
 GKMatchDelegate;
 **/
//The match received a status changed data from player;
- (void)match:(GKMatch *)match player:(NSString *)playerID didChangeState:(GKPlayerConnectionState)state;
// The match received data sent from the player.
- (void)match:(GKMatch *)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID;


/**
 GKSessionDelegate;
 */

/* Indicates a connection error occurred with a peer, which includes connection request failures, or disconnects due to timeouts.
 */
- (void)session:(GKSession *)session connectionWithPeerFailed:(NSString *)peerID withError:(NSError *)error;

/* Indicates an error occurred with the session such as failing to make available.
 */
- (void)session:(GKSession *)session didFailWithError:(NSError *)error;

- (void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *)peerID;
- (void)session:(GKSession *)session peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state;
- (void)receiveData:(NSData *)data fromPeer:(NSString *)peer inSession: (GKSession *)session context:(void *)context;
@end
