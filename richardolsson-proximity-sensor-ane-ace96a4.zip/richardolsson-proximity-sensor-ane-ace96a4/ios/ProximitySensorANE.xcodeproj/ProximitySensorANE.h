//
//  ProximitySensorANE.h
//  ProximitySensorANE
//
//  Created by Richard Olsson on 2011-10-31.
//  Copyright 2011 Richard Olsson Web Development AB. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ProximitySensorANE {
    
}

@end
