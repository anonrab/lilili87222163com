You will need to bring in the FlashRuntimeExtensions.h from you SDK installation at:

{SDK}/include/FlashRuntimeExtensions.h
