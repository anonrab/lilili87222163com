unzip -o Microphone_ANE_ASlib.swc
bin/adt -package -storetype pkcs12 -keystore selfsigned.p12 -storepass 1234 -target ane ext/Microphone.ane extension.xml -swc Microphone_ANE_ASlib.swc -platform iPhone-ARM  library.swf libMicrophoneANE.a 
bin/adt -package -target ipa-test-interpreter -provisioning-profile mic_ane_dev.mobileprovision -storetype pkcs12 -keystore jameslidevelopment.p12 -storepass 1234 micAneExample.ipa info-app.xml micphone.swf -extdir ext
