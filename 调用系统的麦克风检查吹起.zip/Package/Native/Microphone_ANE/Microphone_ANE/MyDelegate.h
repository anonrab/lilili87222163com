//
//  MyDelegate.h
//  GodOfFrog
//
//  Created by James Li on 11/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import "FlashRuntimeExtensions.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


extern FREContext g_ctx;

@interface MyDelegate :NSObject <AVAudioRecorderDelegate>{
    
}


@end
