//
//  MyDelegate.m
//  GodOfFrog
//
//  Created by James Li on 11/19/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "MyDelegate.h"
#import "UIKit/UIKit.h"
#import "CoreGraphics/CoreGraphics.h"

@implementation MyDelegate



@end
