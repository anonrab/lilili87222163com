//
//  capiextension.m
//  GameCenterLib
//
//  Created by James Li on 10/9/11.
//  Copyright 2011 Adobe Systems. All rights reserved.
//

#import "FlashRuntimeExtensions.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "MyDelegate.h"
#import <AudioToolbox/AudioToolbox.h>

FREContext g_ctx=nil;
MyDelegate *observer =nil;
AVAudioRecorder *recorder;
NSTimer *levelTimer;
double lowPassResults;
AVAudioSession *session;

/**
 Debug method, 
 Call from ActionScript to create a native alert window.
 */
FREObject alert(FREContext ctx,void* funcData, uint32_t argc, FREObject argv[]){
    const uint8_t* title = nil;
    const uint8_t* msg = nil;
    uint32_t len = -1;
    
    FREGetObjectAsUTF8(argv[0], &len, &title);
    FREGetObjectAsUTF8(argv[1], &len, &msg);
    
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithUTF8String:(const char *)title]
                                                    message:[NSString stringWithUTF8String:(const char *)msg] delegate:nil 
                                          cancelButtonTitle:@"Cancel" 
                                          otherButtonTitles:nil,nil];
    [alert show];
    //[alert release];
    
    
    return nil;
}




FREObject initMic(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    BOOL success = NO;
    
    if(session == nil){
        session = [AVAudioSession sharedInstance];
        if([session inputIsAvailable]){
            [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
           // [session 
            //UInt32 sessionCategory = kAudioSessionCategory_PlayAndRecord;
            UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
           // AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(sessionCategory), &sessionCategory);
            AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRouteOverride), &audioRouteOverride);
            
           // AudioSessionSetActive(true);
            
            
           // [session setCategory:AVAudioSessionCategoryAmbient error:nil];
            NSURL *url = [NSURL fileURLWithPath:@"/dev/null"];
            
            NSDictionary *settings = [NSDictionary dictionaryWithObjectsAndKeys:
                                      [NSNumber numberWithFloat: 44100.0],                 AVSampleRateKey,
                                      [NSNumber numberWithInt: kAudioFormatAppleLossless], AVFormatIDKey,
                                      [NSNumber numberWithInt: 1],                         AVNumberOfChannelsKey,
                                      [NSNumber numberWithInt: AVAudioQualityMax],         AVEncoderAudioQualityKey,
                                      nil];
            
            NSError *error;
            
            recorder = [[AVAudioRecorder alloc] initWithURL:url settings:settings error:&error];
            
            if (recorder) {
                [recorder prepareToRecord];
                recorder.meteringEnabled = YES;
            }
            
        }
    }
    
    if(recorder){
        [recorder record];
        success = YES;
    }
    
    
    FREObject result;
    FRENewObjectFromBool(success, &result);
    
    return result;
}

FREObject getMicPower(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    [recorder updateMeters];
    
	const double ALPHA = 0.05;
	double peakPowerForChannel = pow(10, (0.05 * [recorder peakPowerForChannel:0]));
	lowPassResults = ALPHA * peakPowerForChannel + (1.0 - ALPHA) * lowPassResults;	
	
    FREObject power;
    
	if (lowPassResults < 0.95){
        
        FRENewObjectFromDouble(lowPassResults, &power);
       // return power;
    }else{
         FRENewObjectFromDouble(-1, &power);
    }
    return power;
}

FREObject removeMic(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    FREObject result;
    if(recorder){
        [recorder stop];
       // FRENewObjectFromBool(YES, &result);
    }else{
       // FRENewObjectFromBool(NO, &result);
    }
     FRENewObjectFromBool(YES, &result);
    
    return result;
}


void ContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, 
                        uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
	NSLog(@"Context Created");
	*numFunctionsToTest = 4;
	FRENamedFunction* func = (FRENamedFunction*)malloc(sizeof(FRENamedFunction)*4);

    
    func[0].name = (const uint8_t*)"alert";
	func[0].functionData = NULL;
	func[0].function = &alert;
    
    func[1].name = (const uint8_t*)"initMic";
	func[1].functionData = NULL;
	func[1].function = &initMic;
    
    func[2].name = (const uint8_t*)"getMicPower";
	func[2].functionData = NULL;
	func[2].function = &getMicPower;
    
    func[3].name = (const uint8_t*)"removeMic";
	func[3].functionData = NULL;
	func[3].function = &removeMic;
    
    g_ctx = ctx;
    observer = [[MyDelegate alloc] init];
 
    
	*functionsToSet = func;
	//// Set the globals.
}

void ContextFinalizer(FREContext ctx) { 
	NSLog(@"Context Distroyed");
}

void ExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet) {
	NSLog(@"Extension Initialized");
	*extDataToSet = NULL;
	*ctxInitializerToSet = &ContextInitializer;
	*ctxFinalizerToSet = &ContextFinalizer;
}

void ExtFinalizer(void* extData) {
	NSLog(@"Extension Destroyed");
}
